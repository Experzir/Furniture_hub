package com.web.furniturehub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FurniturehubApplicationTests {

	@Test
	void contextLoads() {
	}

}
