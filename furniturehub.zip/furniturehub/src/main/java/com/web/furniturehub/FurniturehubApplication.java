package com.web.furniturehub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FurniturehubApplication {

	public static void main(String[] args) {
		SpringApplication.run(FurniturehubApplication.class, args);
	}

}
